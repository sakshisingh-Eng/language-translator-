// const microphoneIcon = document.getElementById("microphone");
// const fromText = document.querySelector(".from-text");

// microphoneIcon.addEventListener("click", function () {
//   // // Initialize the SpeechRecognition object
//   // const recognition = new webkitSpeechRecognition() || SpeechRecognition();
//   // recognition.lang = "en-US";

//   // // Define event handler for when speech is recognized
//   // recognition.onresult = function (event) {
//   //   const transcript = event.results[event.results.length - 1][0].transcript;
//   //   fromText.value += transcript;
//   // };

//   // // Define event handler for errors
//   // recognition.onerror = function (event) {
//   //   console.error("Speech recognition error:", event.error);
//   // };

//   // Define event handler for when user clicks the microphone icon
//   // microphoneIcon.addEventListener('click', function() {
//   //   recognition.start();
//   // });

//   console.log("microphone icon clicked");
// });

/**************************************************************************************** */
// var microphoneBtn = document.getElementById("microphone")

// microphoneBtn.addEventListener("click",function(){
 

//   //  Initialize the SpeechRecognition object
//   const recognition = new webkitSpeechRecognition() || SpeechRecognition();
//   recognition.lang = "en-US";

//   // Define event handler for when speech is recognized
//   recognition.onresult = function (event) {
//     const transcript = event.results[event.results.length - 1][0].transcript;
//     fromText.value += transcript;
//   };

//   // Define event handler for errors
//   recognition.onerror = function (event) {
//     console.error("Speech recognition error:", event.error);
//   };

//   // Define event handler for when user clicks the microphone icon
//   // microphoneIcon.addEventListener('click', function() {
//   //   recognition.start();
//   // });

//   console.log("microphone icon clicked");

// })
